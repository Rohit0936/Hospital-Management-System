class user{

    reguser(name,email)
    {
        this.name=name;
        this.email=email;
    }
}

module.exports=user;